#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/third_party/llama.cpp"
COMMIT="c060ca974c773c7c3d17fd1b66dc9d312bc292c0"

rm -rf "$DEST"
git clone --filter=blob:none --no-checkout https://github.com/ggml-org/llama.cpp.git "$DEST"
git -C "$DEST" fetch --depth=1 origin "$COMMIT"
git -C "$DEST" checkout --detach "$COMMIT"
echo "llama.cpp pinned at $(git -C "$DEST" rev-parse HEAD)"
