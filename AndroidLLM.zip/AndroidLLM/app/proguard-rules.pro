# Engine-specific JNI keep rules will be added with the native adapters.
