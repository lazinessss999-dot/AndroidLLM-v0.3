package app.androidllm.mobile.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.androidllm.core.inference.EngineState
import app.androidllm.core.model.DevicePreset
import app.androidllm.core.model.EngineType
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.Modality
import app.androidllm.core.model.PerformanceTier
import app.androidllm.mobile.R
import app.androidllm.mobile.ui.CustomModelKind
import app.androidllm.mobile.ui.DeviceInfo
import app.androidllm.mobile.ui.ModelImportStatus
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(
    contentPadding: PaddingValues,
    models: List<LocalModel>,
    selectedModel: LocalModel?,
    engineState: EngineState,
    importStatus: ModelImportStatus,
    error: String?,
    deviceInfo: DeviceInfo,
    resolvedPreset: DevicePreset,
    onImport: (modelId: String, uri: String) -> Unit,
    onImportCustom: (kind: CustomModelKind, uri: String) -> Unit,
    onDismissImportError: () -> Unit,
    onSelect: (LocalModel) -> Unit,
    onOpenChat: () -> Unit,
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    var importTarget by remember { mutableStateOf<String?>(null) }
    var customImportKind by remember { mutableStateOf<CustomModelKind?>(null) }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val target = importTarget
        val customKind = customImportKind
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            when {
                target != null -> onImport(target, uri.toString())
                customKind != null -> onImportCustom(customKind, uri.toString())
            }
        }
        importTarget = null
        customImportKind = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
    ) {
        TopAppBar(title = { Text(stringResource(R.string.models_title)) })
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    text = stringResource(
                        R.string.models_device_profile,
                        deviceInfo.modelName,
                        deviceInfo.ramGb,
                        deviceInfo.cores,
                        presetLabel(resolvedPreset),
                    ),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = stringResource(R.string.models_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                if (importStatus.error != null) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(importStatus.error, color = MaterialTheme.colorScheme.onErrorContainer)
                            TextButton(onClick = onDismissImportError) {
                                Text(stringResource(R.string.dismiss))
                            }
                        }
                    }
                }
                if (error != null) {
                    Text(
                        text = stringResource(R.string.engine_error, error),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    ),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.add_own_model),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = stringResource(R.string.add_own_model_note),
                            style = MaterialTheme.typography.bodySmall,
                        )
                        OutlinedButton(
                            onClick = {
                                customImportKind = CustomModelKind.GGUF_TEXT
                                modelPicker.launch(arrayOf("application/octet-stream", "*/*"))
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(R.string.add_gguf_model)) }
                        OutlinedButton(
                            onClick = {
                                customImportKind = CustomModelKind.LITERT_TEXT
                                modelPicker.launch(arrayOf("application/octet-stream", "*/*"))
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(R.string.add_litert_model)) }
                        OutlinedButton(
                            onClick = {
                                customImportKind = CustomModelKind.LITERT_VLM
                                modelPicker.launch(arrayOf("application/octet-stream", "*/*"))
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(R.string.add_litert_vlm)) }
                        if (importStatus.modelId != null && models.none { it.id == importStatus.modelId }) {
                            LinearProgressIndicator(
                                progress = { importStatus.progressPercent / 100f },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Text(stringResource(R.string.import_progress, importStatus.progressPercent))
                        }
                    }
                }
            }
            items(models, key = LocalModel::id) { model ->
                ModelCard(
                    model = model,
                    selected = model.id == selectedModel?.id,
                    loading = engineState is EngineState.Loading && engineState.modelId == model.id,
                    importingProgress = importStatus
                        .takeIf { it.modelId == model.id }
                        ?.progressPercent,
                    onDownload = { uriHandler.openUri(model.downloadUrl) },
                    onOpenModelCard = { uriHandler.openUri(model.modelCardUrl) },
                    onImport = {
                        importTarget = model.id
                        modelPicker.launch(arrayOf("application/octet-stream", "*/*"))
                    },
                    onSelect = { onSelect(model) },
                    onOpenChat = onOpenChat,
                )
            }
        }
    }
}

@Composable
private fun ModelCard(
    model: LocalModel,
    selected: Boolean,
    loading: Boolean,
    importingProgress: Int?,
    onDownload: () -> Unit,
    onOpenModelCard: () -> Unit,
    onImport: () -> Unit,
    onSelect: () -> Unit,
    onOpenChat: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ),
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(
                text = model.displayName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = when (model.engineType) {
                    EngineType.LITERT -> stringResource(R.string.engine_litert)
                    EngineType.GGUF -> stringResource(R.string.engine_gguf)
                },
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(stringResource(R.string.text_capability)) })
                if (Modality.IMAGE in model.modalities) {
                    AssistChip(onClick = {}, label = { Text(stringResource(R.string.image_capability)) })
                }
                if (model.isCustom) {
                    AssistChip(onClick = {}, label = { Text(stringResource(R.string.custom_model)) })
                }
                AssistChip(
                    onClick = {},
                    label = {
                        Text(
                            when (model.performanceTier) {
                                PerformanceTier.FAST -> stringResource(R.string.performance_fast)
                                PerformanceTier.BALANCED -> stringResource(R.string.performance_balanced)
                                PerformanceTier.SLOW -> stringResource(R.string.performance_slow)
                            },
                        )
                    },
                )
            }
            Text(
                text = stringResource(R.string.format_label, model.format),
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                text = stringResource(R.string.size_label, formatBytes(model.sizeBytes)),
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                text = stringResource(R.string.context_label, model.recommendedContextSize),
                style = MaterialTheme.typography.bodySmall,
            )
            if (!model.isCustom) {
                Text(
                    text = stringResource(R.string.public_link_no_auth),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (!model.runtimeAvailable) {
                Text(
                    text = stringResource(R.string.runtime_coming_next),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary,
                )
            }

            if (importingProgress != null) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { importingProgress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(stringResource(R.string.import_progress, importingProgress))
            }

            Spacer(Modifier.height(14.dp))
            if (!model.isCustom) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onDownload) {
                        Text(stringResource(R.string.download_model))
                    }
                    OutlinedButton(onClick = onImport, enabled = importingProgress == null) {
                        Text(stringResource(R.string.import_model))
                    }
                }
                TextButton(onClick = onOpenModelCard) {
                    Text(stringResource(R.string.open_model_card))
                }
            }

            if (model.isInstalled) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onSelect,
                        enabled = model.runtimeAvailable && !selected && !loading,
                    ) {
                        Text(
                            when {
                                loading -> stringResource(R.string.loading_model)
                                selected -> stringResource(R.string.selected_model)
                                else -> stringResource(R.string.use_model)
                            },
                        )
                    }
                    if (selected) {
                        OutlinedButton(onClick = onOpenChat) {
                            Text(stringResource(R.string.open_chat))
                        }
                    }
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    val mb = bytes / 1_000_000.0
    return if (mb >= 1_000) {
        String.format(Locale.US, "%.2f GB", mb / 1_000)
    } else {
        String.format(Locale.US, "%.0f MB", mb)
    }
}
