package app.androidllm.mobile.ui

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.androidllm.core.inference.ChatRequest
import app.androidllm.core.inference.ChatSession
import app.androidllm.core.inference.EngineState
import app.androidllm.core.inference.GenerationEvent
import app.androidllm.core.inference.InferenceEngine
import app.androidllm.core.inference.InferenceMetrics
import app.androidllm.core.inference.LoadOptions
import app.androidllm.core.inference.SessionConfig
import app.androidllm.core.model.AttachedDocument
import app.androidllm.core.model.ChatMessage
import app.androidllm.core.model.ChatRole
import app.androidllm.core.model.DevicePreset
import app.androidllm.core.model.EngineType
import app.androidllm.core.model.GenerationConfig
import app.androidllm.core.model.ImageAttachment
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.ModelOverrides
import app.androidllm.core.model.Modality
import app.androidllm.core.model.PerformanceTier
import app.androidllm.engine.gguf.GgufInferenceEngine
import app.androidllm.engine.litert.LiteRtInferenceEngine
import app.androidllm.mobile.rag.RagRetriever
import java.io.File
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ModelImportStatus(
    val modelId: String? = null,
    val progressPercent: Int = 0,
    val error: String? = null,
)

enum class CustomModelKind {
    LITERT_TEXT,
    LITERT_VLM,
    GGUF_TEXT,
}

data class DeviceInfo(
    val modelName: String,
    val ramGb: Int,
    val cores: Int,
)

class AndroidLlmViewModel(application: Application) : AndroidViewModel(application) {
    private var activeEngine: InferenceEngine? = null
    private var session: ChatSession? = null
    private var generationJob: Job? = null

    private val modelsDir = File(application.filesDir, "models").apply { mkdirs() }
    private val customCatalogFile = File(application.filesDir, "custom_models.json")
    private val modelSettingsFile = File(application.filesDir, "model_settings.json")

    private val prefs = application.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    private val detectedRamGb: Int = run {
        val activityManager = application.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        (memoryInfo.totalMem / (1024L * 1024L * 1024L)).toInt().coerceAtLeast(1)
    }
    private val detectedCores: Int = Runtime.getRuntime().availableProcessors()

    val deviceInfo = DeviceInfo(
        modelName = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
        ramGb = detectedRamGb,
        cores = detectedCores,
    )

    private val mutablePresetSelection = MutableStateFlow(
        prefs.getString(KEY_PRESET, DevicePreset.AUTO) ?: DevicePreset.AUTO,
    )
    val presetSelection = mutablePresetSelection.asStateFlow()

    private val mutableResolvedPreset = MutableStateFlow(resolvePreset(mutablePresetSelection.value))
    val resolvedPreset = mutableResolvedPreset.asStateFlow()

    private val mutableOverrides = MutableStateFlow(loadOverrides())
    val modelOverrides = mutableOverrides.asStateFlow()

    private val catalog = listOf(
        LocalModel(
            id = "qwen3-0.6b-litert-int4",
            displayName = "Qwen3 0.6B · LiteRT INT4",
            engineType = EngineType.LITERT,
            format = ".litertlm · INT4",
            sizeBytes = 344_437_808,
            modalities = setOf(Modality.TEXT),
            fileName = "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm",
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true",
            modelCardUrl = "https://huggingface.co/litert-community/Qwen3-0.6B",
            sha256 = "e3e290109da4388d65a17510a0c66af91c8039f52d2c465868dbc43c09a776cf",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.FAST,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "smolvlm2-500m-litert",
            displayName = "SmolVLM2 500M · Vision",
            engineType = EngineType.LITERT,
            format = ".litertlm · INT4/INT8",
            sizeBytes = 361_052_336,
            modalities = setOf(Modality.TEXT, Modality.IMAGE),
            fileName = "SmolVLM2-500M.litertlm",
            downloadUrl = "https://huggingface.co/litert-community/SmolVLM2-500M/resolve/main/SmolVLM2-500M.litertlm?download=true",
            modelCardUrl = "https://huggingface.co/litert-community/SmolVLM2-500M",
            sha256 = "0dfb6fb881eb16e5ef2b2be04de5476caf939b7d9ae601fdee308bbc5462fd55",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.BALANCED,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "qwen2.5-0.5b-gguf-q4km",
            displayName = "Qwen2.5 0.5B · GGUF Q4_K_M",
            engineType = EngineType.GGUF,
            format = ".gguf · Q4_K_M",
            sizeBytes = 491_400_032,
            modalities = setOf(Modality.TEXT),
            fileName = "qwen2.5-0.5b-instruct-q4_k_m.gguf",
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf?download=true",
            modelCardUrl = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF",
            sha256 = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.FAST,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "qwen2.5-1.5b-gguf-q4km",
            displayName = "Qwen2.5 1.5B · GGUF Q4_K_M",
            engineType = EngineType.GGUF,
            format = ".gguf · Q4_K_M",
            sizeBytes = 1_117_320_736,
            modalities = setOf(Modality.TEXT),
            fileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true",
            modelCardUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF",
            sha256 = "6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.SLOW,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "qwen2.5-1.5b-litert-q8",
            displayName = "Qwen2.5 1.5B Instruct · LiteRT Q8",
            engineType = EngineType.LITERT,
            format = ".litertlm · dynamic INT8",
            sizeBytes = 1_597_931_520,
            modalities = setOf(Modality.TEXT),
            fileName = "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm",
            downloadUrl = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm?download=true",
            modelCardUrl = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct",
            sha256 = "faa60663b333290c1496c499828b21d3e3254a788cacd8cce917ce0f761a2dc9",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.SLOW,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "qwen2.5-coder-1.5b-gguf-q4km",
            displayName = "Qwen2.5 Coder 1.5B Instruct · GGUF",
            engineType = EngineType.GGUF,
            format = ".gguf · Q4_K_M",
            sizeBytes = 1_117_320_768,
            modalities = setOf(Modality.TEXT),
            fileName = "qwen2.5-coder-1.5b-instruct-q4_k_m.gguf",
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf?download=true",
            modelCardUrl = "https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF",
            sha256 = "cc324af070c2ecbfd324a30884d2f951a7ff756aba85cb811a6ec436933bb046",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.SLOW,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "smollm2-1.7b-instruct-gguf-q4km",
            displayName = "SmolLM2 1.7B Instruct · GGUF",
            engineType = EngineType.GGUF,
            format = ".gguf · Q4_K_M",
            sizeBytes = 1_055_609_536,
            modalities = setOf(Modality.TEXT),
            fileName = "smollm2-1.7b-instruct-q4_k_m.gguf",
            downloadUrl = "https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct-GGUF/resolve/main/smollm2-1.7b-instruct-q4_k_m.gguf?download=true",
            modelCardUrl = "https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct-GGUF",
            sha256 = "decd2598bc2c8ed08c19adc3c8fdd461ee19ed5708679d1c54ef54a5a30d4f33",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.SLOW,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "llama-3.2-1b-instruct-gguf-q4km",
            displayName = "Llama 3.2 1B Instruct · GGUF",
            engineType = EngineType.GGUF,
            format = ".gguf · Q4_K_M",
            sizeBytes = 807_694_464,
            modalities = setOf(Modality.TEXT),
            fileName = "Llama-3.2-1B-Instruct-Q4_K_M.gguf",
            downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf?download=true",
            modelCardUrl = "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF",
            sha256 = "6f85a640a97cf2bf5b8e764087b1e83da0fdb51d7c9fab7d0fece9385611df83",
            license = "Llama 3.2 Community License",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.BALANCED,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "qwen2-vl-2b-litert",
            displayName = "Qwen2-VL 2B Instruct · VLM",
            engineType = EngineType.LITERT,
            format = ".litertlm · VLM INT4/INT8",
            sizeBytes = 1_784_096_288,
            modalities = setOf(Modality.TEXT, Modality.IMAGE),
            fileName = "Qwen2-VL-2B.litertlm",
            downloadUrl = "https://huggingface.co/litert-community/Qwen2-VL-2B/resolve/main/Qwen2-VL-2B.litertlm?download=true",
            modelCardUrl = "https://huggingface.co/litert-community/Qwen2-VL-2B",
            sha256 = "a9fd50536f8c521ae7cc1d56a3c58b405b2be83b3899ea8dfca9858eee9a4296",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.SLOW,
            runtimeAvailable = true,
        ),
        LocalModel(
            id = "smolvlm2-2.2b-litert",
            displayName = "SmolVLM2 2.2B Instruct · VLM",
            engineType = EngineType.LITERT,
            format = ".litertlm · VLM INT4/INT8",
            sizeBytes = 1_511_353_264,
            modalities = setOf(Modality.TEXT, Modality.IMAGE),
            fileName = "SmolVLM2-2.2B.litertlm",
            downloadUrl = "https://huggingface.co/litert-community/SmolVLM2-2.2B/resolve/main/SmolVLM2-2.2B.litertlm?download=true",
            modelCardUrl = "https://huggingface.co/litert-community/SmolVLM2-2.2B",
            sha256 = "c3adc6bc0ef25f1ac4f9fcf5c1be0b4440aac38929671baa3f84bb31012c0835",
            recommendedContextSize = 2048,
            performanceTier = PerformanceTier.SLOW,
            runtimeAvailable = true,
        ),
    )

    private val mutableModels = MutableStateFlow(
        catalog.map(::restoreInstalledState) + loadCustomModels(),
    )
    val models = mutableModels.asStateFlow()

    private val mutableEngineState = MutableStateFlow<EngineState>(EngineState.Idle)
    val engineState = mutableEngineState.asStateFlow()

    private val mutableImportStatus = MutableStateFlow(ModelImportStatus())
    val importStatus = mutableImportStatus.asStateFlow()

    private val mutableSelectedModel = MutableStateFlow<LocalModel?>(null)
    val selectedModel = mutableSelectedModel.asStateFlow()

    private val mutableMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = mutableMessages.asStateFlow()

    private val mutableConfig = MutableStateFlow(
        GenerationConfig(
            temperature = prefs.getFloat(KEY_TEMPERATURE, 0.7f),
            topP = prefs.getFloat(KEY_TOP_P, 0.95f),
            topK = prefs.getInt(KEY_TOP_K, 40),
            systemPrompt = prefs.getString(KEY_SYSTEM_PROMPT, "You are a helpful local assistant.")
                ?: "You are a helpful local assistant.",
            showThinking = prefs.getBoolean(KEY_SHOW_THINKING, false),
            renderMarkdown = prefs.getBoolean(KEY_MARKDOWN, true),
        ),
    )
    val config = mutableConfig.asStateFlow()

    private val mutableBackendPreference = MutableStateFlow(
        prefs.getString(KEY_BACKEND, mutableResolvedPreset.value.backend) ?: mutableResolvedPreset.value.backend,
    )
    val backendPreference = mutableBackendPreference.asStateFlow()

    private val mutableActiveBackend = MutableStateFlow<String?>(null)
    val activeBackend = mutableActiveBackend.asStateFlow()

    private val mutableAttachment = MutableStateFlow<ImageAttachment?>(null)
    val attachment = mutableAttachment.asStateFlow()

    private val mutableDocuments = MutableStateFlow<List<AttachedDocument>>(emptyList())
    val documents = mutableDocuments.asStateFlow()

    private val mutableIsGenerating = MutableStateFlow(false)
    val isGenerating = mutableIsGenerating.asStateFlow()

    private val mutableMetrics = MutableStateFlow<InferenceMetrics?>(null)
    val metrics = mutableMetrics.asStateFlow()

    private val mutableError = MutableStateFlow<String?>(null)
    val error = mutableError.asStateFlow()

    fun importModel(modelId: String, uriString: String) {
        val model = mutableModels.value.firstOrNull { it.id == modelId } ?: return
        if (mutableImportStatus.value.modelId != null) return

        viewModelScope.launch {
            mutableImportStatus.value = ModelImportStatus(modelId = modelId)
            val result = runCatching {
                withContext(Dispatchers.IO) { copyAndVerifyModel(model, Uri.parse(uriString)) }
            }
            result.onSuccess { destination ->
                mutableModels.update { list ->
                    list.map {
                        if (it.id == modelId) it.copy(
                            location = destination.absolutePath,
                            isInstalled = true,
                        ) else it
                    }
                }
                mutableImportStatus.value = ModelImportStatus()
            }.onFailure { throwable ->
                mutableImportStatus.value = ModelImportStatus(
                    error = throwable.message ?: throwable::class.simpleName,
                )
            }
        }
    }

    fun importCustomModel(kind: CustomModelKind, uriString: String) {
        if (mutableImportStatus.value.modelId != null) return
        viewModelScope.launch {
            mutableImportStatus.value = ModelImportStatus(modelId = CUSTOM_IMPORT_ID)
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    copyCustomModel(kind, Uri.parse(uriString))
                }
            }
            result.onSuccess { model ->
                mutableModels.update { list ->
                    list.filterNot { it.id == model.id } + model
                }
                saveCustomModels()
                mutableImportStatus.value = ModelImportStatus()
            }.onFailure { throwable ->
                mutableImportStatus.value = ModelImportStatus(
                    error = throwable.message ?: throwable::class.simpleName,
                )
            }
        }
    }

    fun clearImportError() {
        mutableImportStatus.value = ModelImportStatus()
    }

    fun selectModel(model: LocalModel) {
        loadSelectedModel(model, forceReload = false)
    }

    fun setBackendPreference(value: String) {
        val normalized = value.uppercase()
        if (normalized !in setOf("AUTO", "CPU", "GPU")) return
        if (mutableBackendPreference.value == normalized) return
        mutableBackendPreference.value = normalized
        prefs.edit().putString(KEY_BACKEND, normalized).apply()
        mutableSelectedModel.value?.let { loadSelectedModel(it, forceReload = true) }
    }

    private fun loadSelectedModel(model: LocalModel, forceReload: Boolean) {
        if (!model.isInstalled) {
            mutableError.value = "Сначала скачайте и импортируйте файл модели"
            return
        }
        if (!model.runtimeAvailable) {
            mutableError.value = "Runtime для этой модели недоступен"
            return
        }
        if (!forceReload && model.id == mutableSelectedModel.value?.id && engineState.value is EngineState.Ready) return

        viewModelScope.launch {
            val requestedBackend = effectiveBackendFor(model)
            mutableEngineState.value = EngineState.Loading(model.id, requestedBackend)
            runCatching {
                generationJob?.cancel()
                session?.close()
                session = null
                activeEngine?.unload()
                activeEngine?.close()
                activeEngine = createEngine(model.engineType)
                mutableSelectedModel.value = null
                mutableActiveBackend.value = null
                mutableMessages.value = emptyList()
                mutableMetrics.value = null
                mutableError.value = null

                val effective = effectiveConfigFor(model)
                activeEngine?.load(
                    model,
                    LoadOptions(
                        backend = requestedBackend,
                        contextSize = effective.contextSize,
                    ),
                )
                val resolvedBackend = activeEngine?.activeBackend?.value ?: "CPU"
                session = activeEngine?.createSession(SessionConfig(effective))
                mutableSelectedModel.value = model
                mutableActiveBackend.value = resolvedBackend
                mutableEngineState.value = EngineState.Ready(model.id, resolvedBackend)
            }.onFailure { throwable ->
                mutableActiveBackend.value = null
                mutableEngineState.value = EngineState.Failed(
                    throwable.message ?: throwable::class.simpleName.orEmpty(),
                )
                mutableError.value = throwable.message ?: throwable::class.simpleName
            }
        }
    }

    fun attachImage(uri: String) {
        mutableAttachment.value = ImageAttachment(uri = uri, displayName = uri.substringAfterLast('/'))
    }

    fun removeAttachment() {
        mutableAttachment.value = null
    }

    fun attachDocument(uriString: String) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { readDocument(Uri.parse(uriString)) }
            }
            result.onSuccess { document ->
                mutableDocuments.update { list -> list + document }
                mutableError.value = null
            }.onFailure { throwable ->
                mutableError.value = throwable.message ?: throwable::class.simpleName
            }
        }
    }

    fun removeDocument(documentId: String) {
        mutableDocuments.update { list -> list.filterNot { it.id == documentId } }
    }

    fun clearDocuments() {
        mutableDocuments.value = emptyList()
    }

    private fun readDocument(uri: Uri): AttachedDocument {
        val resolver = getApplication<Application>().contentResolver
        val name = queryDocument(uri).first
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Не удалось открыть выбранный файл")
        require(bytes.size.toLong() <= RagRetriever.MAX_FILE_BYTES) {
            "Файл слишком большой (максимум 2 МБ)"
        }
        val text = String(bytes, Charsets.UTF_8).trim()
        require(text.isNotEmpty()) { "Файл пуст или не является текстовым" }
        return AttachedDocument(name = name, text = text)
    }

    fun sendMessage(text: String) {
        val activeSession = session ?: return
        if (text.isBlank() || mutableIsGenerating.value) return

        val images = listOfNotNull(mutableAttachment.value)
        val userMessage = ChatMessage(
            role = ChatRole.USER,
            text = text.trim(),
            images = images,
        )
        val assistantMessage = ChatMessage(
            role = ChatRole.ASSISTANT,
            text = "",
            isStreaming = true,
        )
        val history = mutableMessages.value
        mutableMessages.value = history + userMessage + assistantMessage
        mutableAttachment.value = null
        mutableMetrics.value = null
        mutableError.value = null
        mutableIsGenerating.value = true

        generationJob = viewModelScope.launch {
            runCatching {
                activeSession.generate(
                    ChatRequest(
                        text = buildRequestText(userMessage.text),
                        history = history + userMessage,
                        images = images,
                    ),
                ).collect { event ->
                    when (event) {
                        GenerationEvent.Started -> Unit
                        is GenerationEvent.TextDelta -> updateAssistant(assistantMessage.id) {
                            it.copy(text = it.text + event.text)
                        }
                        is GenerationEvent.ThinkingDelta -> updateAssistant(assistantMessage.id) {
                            it.copy(thinking = it.thinking + event.text)
                        }
                        is GenerationEvent.Metrics -> mutableMetrics.value = event.value
                        GenerationEvent.Completed -> updateAssistant(assistantMessage.id) {
                            it.copy(isStreaming = false)
                        }
                    }
                }
            }.onFailure { throwable ->
                mutableError.value = throwable.message ?: throwable::class.simpleName
                updateAssistant(assistantMessage.id) { it.copy(isStreaming = false) }
            }
            mutableIsGenerating.value = false
        }
    }

    fun stopGeneration() {
        viewModelScope.launch {
            session?.stop()
            generationJob?.cancel()
            mutableMessages.update { list ->
                list.map { if (it.isStreaming) it.copy(isStreaming = false) else it }
            }
            mutableIsGenerating.value = false
        }
    }

    /**
     * Prepends the most relevant excerpts of the attached documents to the
     * question. The chat bubble keeps showing the original question only.
     */
    private fun buildRequestText(question: String): String {
        val docs = mutableDocuments.value
        if (docs.isEmpty()) return question
        val context = RagRetriever.retrieve(question, docs)
        if (context.isBlank()) return question
        return buildString {
            append("Answer the question using the provided context. ")
            append("If the context does not contain the answer, say so.\n\n")
            append("Context:\n")
            append(context)
            append("\n\nQuestion: ")
            append(question)
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            generationJob?.cancel()
            session?.reset()
            mutableMessages.value = emptyList()
            mutableMetrics.value = null
            mutableIsGenerating.value = false
        }
    }

    fun setTemperature(value: Float) {
        mutableConfig.update { it.copy(temperature = value) }
        prefs.edit().putFloat(KEY_TEMPERATURE, value).apply()
        refreshSessionIfIdle()
    }

    fun setTopP(value: Float) {
        mutableConfig.update { it.copy(topP = value) }
        prefs.edit().putFloat(KEY_TOP_P, value).apply()
        refreshSessionIfIdle()
    }

    fun setTopK(value: Int) {
        mutableConfig.update { it.copy(topK = value) }
        prefs.edit().putInt(KEY_TOP_K, value).apply()
        refreshSessionIfIdle()
    }

    fun setShowThinking(value: Boolean) {
        mutableConfig.update { it.copy(showThinking = value) }
        prefs.edit().putBoolean(KEY_SHOW_THINKING, value).apply()
        refreshSessionIfIdle()
    }

    fun setMarkdown(value: Boolean) {
        mutableConfig.update { it.copy(renderMarkdown = value) }
        prefs.edit().putBoolean(KEY_MARKDOWN, value).apply()
    }

    fun setSystemPrompt(value: String) {
        mutableConfig.update { it.copy(systemPrompt = value) }
        prefs.edit().putString(KEY_SYSTEM_PROMPT, value).apply()
        refreshSessionIfIdle()
    }

    fun setDevicePreset(selection: String) {
        val normalized = selection.uppercase()
        if (normalized != DevicePreset.AUTO && DevicePreset.entries.none { it.name == normalized }) return
        if (mutablePresetSelection.value == normalized) return
        mutablePresetSelection.value = normalized
        mutableResolvedPreset.value = resolvePreset(normalized)
        prefs.edit().putString(KEY_PRESET, normalized).apply()
        mutableBackendPreference.value = mutableResolvedPreset.value.backend
        reloadSelectedIfLoaded()
    }

    fun setModelContextSize(modelId: String, value: Int) {
        updateOverride(modelId) { it.copy(contextSize = value) }
        reloadSelectedIfLoaded(modelId)
    }

    fun setModelMaxOutputTokens(modelId: String, value: Int) {
        updateOverride(modelId) { it.copy(maxOutputTokens = value) }
        refreshSessionIfIdle(modelId)
    }

    fun setModelTemperature(modelId: String, value: Float) {
        updateOverride(modelId) { it.copy(temperature = value) }
        refreshSessionIfIdle(modelId)
    }

    fun setModelTopP(modelId: String, value: Float) {
        updateOverride(modelId) { it.copy(topP = value) }
        refreshSessionIfIdle(modelId)
    }

    fun setModelTopK(modelId: String, value: Int) {
        updateOverride(modelId) { it.copy(topK = value) }
        refreshSessionIfIdle(modelId)
    }

    fun setModelBackend(modelId: String, value: String) {
        updateOverride(modelId) { it.copy(backend = value) }
        reloadSelectedIfLoaded(modelId)
    }

    fun setModelShowThinking(modelId: String, value: Boolean) {
        updateOverride(modelId) { it.copy(showThinking = value) }
        refreshSessionIfIdle(modelId)
    }

    fun resetModelOverrides(modelId: String) {
        mutableOverrides.update { it - modelId }
        saveOverrides()
        reloadSelectedIfLoaded(modelId)
    }

    private fun updateOverride(modelId: String, transform: (ModelOverrides) -> ModelOverrides) {
        val current = mutableOverrides.value[modelId] ?: ModelOverrides()
        mutableOverrides.update { it + (modelId to transform(current)) }
        saveOverrides()
    }

    private fun reloadSelectedIfLoaded(modelId: String? = null) {
        val selected = mutableSelectedModel.value ?: return
        if (modelId != null && selected.id != modelId) return
        loadSelectedModel(selected, forceReload = true)
    }

    /** Recreates the chat session so sampler settings apply immediately (only while the chat is empty). */
    private fun refreshSessionIfIdle(modelId: String? = null) {
        val model = mutableSelectedModel.value ?: return
        val engine = activeEngine ?: return
        if (modelId != null && model.id != modelId) return
        if (engineState.value !is EngineState.Ready) return
        if (mutableMessages.value.isNotEmpty()) return
        viewModelScope.launch {
            runCatching {
                session?.close()
                session = null
                session = engine.createSession(SessionConfig(effectiveConfigFor(model)))
            }.onFailure { throwable ->
                mutableError.value = throwable.message ?: throwable::class.simpleName
            }
        }
    }

    private fun resolvePreset(selection: String): DevicePreset =
        if (selection == DevicePreset.AUTO) DevicePreset.forRamGb(detectedRamGb)
        else DevicePreset.valueOf(selection)

    private fun effectiveBackendFor(model: LocalModel): String {
        if (model.engineType == EngineType.GGUF) return "CPU"
        return mutableOverrides.value[model.id]?.backend ?: mutableBackendPreference.value
    }

    private fun effectiveConfigFor(model: LocalModel): GenerationConfig {
        val global = mutableConfig.value
        val preset = mutableResolvedPreset.value
        val overrides = mutableOverrides.value[model.id]
        return GenerationConfig(
            temperature = overrides?.temperature ?: global.temperature,
            topP = overrides?.topP ?: global.topP,
            topK = overrides?.topK ?: global.topK,
            maxOutputTokens = overrides?.maxOutputTokens ?: preset.maxOutputTokens,
            contextSize = overrides?.contextSize ?: preset.contextSize,
            systemPrompt = global.systemPrompt,
            showThinking = overrides?.showThinking ?: global.showThinking,
            renderMarkdown = global.renderMarkdown,
        )
    }

    private fun createEngine(type: EngineType): InferenceEngine = when (type) {
        EngineType.LITERT -> LiteRtInferenceEngine(getApplication())
        EngineType.GGUF -> GgufInferenceEngine(getApplication())
    }

    private fun restoreInstalledState(model: LocalModel): LocalModel {
        val file = File(modelsDir, model.fileName)
        return if (file.isFile && file.length() == model.sizeBytes) {
            model.copy(location = file.absolutePath, isInstalled = true)
        } else {
            model
        }
    }

    private fun copyAndVerifyModel(model: LocalModel, uri: Uri): File {
        val destination = File(modelsDir, model.fileName)
        val temporary = File(modelsDir, "${model.fileName}.part")
        temporary.delete()
        val digest = MessageDigest.getInstance("SHA-256")
        var copied = 0L

        getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось открыть выбранный файл" }
            temporary.outputStream().buffered().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 16)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    output.write(buffer, 0, read)
                    digest.update(buffer, 0, read)
                    copied += read
                    mutableImportStatus.value = ModelImportStatus(
                        modelId = model.id,
                        progressPercent = ((copied * 100) / model.sizeBytes)
                            .toInt()
                            .coerceIn(0, 100),
                    )
                }
            }
        }

        require(copied == model.sizeBytes) {
            "Неверный размер: $copied вместо ${model.sizeBytes} байт"
        }
        val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
        require(actualHash.equals(model.sha256, ignoreCase = true)) {
            "SHA-256 файла не совпадает"
        }
        if (destination.exists()) destination.delete()
        check(temporary.renameTo(destination)) { "Не удалось сохранить модель" }
        return destination
    }

    private fun copyCustomModel(kind: CustomModelKind, uri: Uri): LocalModel {
        val (displayName, reportedSize) = queryDocument(uri)
        val expectedExtension = when (kind) {
            CustomModelKind.GGUF_TEXT -> ".gguf"
            CustomModelKind.LITERT_TEXT, CustomModelKind.LITERT_VLM -> ".litertlm"
        }
        require(displayName.lowercase().endsWith(expectedExtension)) {
            "Ожидался файл $expectedExtension"
        }
        val safeName = displayName
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .takeLast(160)
            .ifBlank { "custom_${System.currentTimeMillis()}$expectedExtension" }
        val destination = File(modelsDir, safeName)
        val temporary = File(modelsDir, "$safeName.part")
        temporary.delete()
        val digest = MessageDigest.getInstance("SHA-256")
        var copied = 0L

        getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось открыть выбранный файл" }
            temporary.outputStream().buffered().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 16)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    output.write(buffer, 0, read)
                    digest.update(buffer, 0, read)
                    copied += read
                    val progress = if (reportedSize > 0) {
                        ((copied * 100) / reportedSize).toInt().coerceIn(0, 100)
                    } else 0
                    mutableImportStatus.value = ModelImportStatus(
                        modelId = CUSTOM_IMPORT_ID,
                        progressPercent = progress,
                    )
                }
            }
        }
        require(copied > 0) { "Выбранный файл пуст" }
        if (reportedSize > 0) require(copied == reportedSize) { "Файл скопирован не полностью" }
        if (kind == CustomModelKind.GGUF_TEXT) {
            val magic = ByteArray(4)
            val magicRead = temporary.inputStream().use { it.read(magic) }
            require(magicRead == 4 && magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) {
                "Файл не содержит сигнатуру GGUF"
            }
        }
        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        if (destination.exists()) destination.delete()
        check(temporary.renameTo(destination)) { "Не удалось сохранить модель" }

        val engineType = if (kind == CustomModelKind.GGUF_TEXT) EngineType.GGUF else EngineType.LITERT
        val modalities = if (kind == CustomModelKind.LITERT_VLM) {
            setOf(Modality.TEXT, Modality.IMAGE)
        } else {
            setOf(Modality.TEXT)
        }
        return LocalModel(
            id = "custom-${hash.take(16)}",
            displayName = displayName.substringBeforeLast('.'),
            engineType = engineType,
            format = expectedExtension,
            sizeBytes = copied,
            modalities = modalities,
            location = destination.absolutePath,
            isInstalled = true,
            fileName = destination.name,
            downloadUrl = "",
            modelCardUrl = "",
            sha256 = hash,
            license = "User-provided model",
            recommendedContextSize = 2048,
            performanceTier = when {
                copied < 700_000_000 -> PerformanceTier.FAST
                copied < 1_300_000_000 -> PerformanceTier.BALANCED
                else -> PerformanceTier.SLOW
            },
            runtimeAvailable = true,
            isCustom = true,
        )
    }

    private fun queryDocument(uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "custom_model"
        var size = -1L
        getApplication<Application>().contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return name to size
    }

    private fun saveCustomModels() {
        val array = JSONArray()
        mutableModels.value.filter(LocalModel::isCustom).forEach { model ->
            array.put(
                JSONObject()
                    .put("id", model.id)
                    .put("displayName", model.displayName)
                    .put("engineType", model.engineType.name)
                    .put("fileName", model.fileName)
                    .put("sizeBytes", model.sizeBytes)
                    .put("sha256", model.sha256)
                    .put("supportsImage", Modality.IMAGE in model.modalities)
                    .put("context", model.recommendedContextSize),
            )
        }
        customCatalogFile.writeText(array.toString())
    }

    private fun loadCustomModels(): List<LocalModel> = runCatching {
        if (!customCatalogFile.isFile) return@runCatching emptyList()
        val array = JSONArray(customCatalogFile.readText())
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val file = File(modelsDir, item.getString("fileName"))
                if (!file.isFile) continue
                val engineType = EngineType.valueOf(item.getString("engineType"))
                val supportsImage = item.optBoolean("supportsImage", false)
                add(
                    LocalModel(
                        id = item.getString("id"),
                        displayName = item.getString("displayName"),
                        engineType = engineType,
                        format = if (engineType == EngineType.GGUF) ".gguf" else ".litertlm",
                        sizeBytes = item.optLong("sizeBytes", file.length()),
                        modalities = if (supportsImage) {
                            setOf(Modality.TEXT, Modality.IMAGE)
                        } else setOf(Modality.TEXT),
                        location = file.absolutePath,
                        isInstalled = true,
                        fileName = file.name,
                        sha256 = item.optString("sha256"),
                        license = "User-provided model",
                        recommendedContextSize = item.optInt("context", 2048),
                        performanceTier = when {
                            file.length() < 700_000_000 -> PerformanceTier.FAST
                            file.length() < 1_300_000_000 -> PerformanceTier.BALANCED
                            else -> PerformanceTier.SLOW
                        },
                        runtimeAvailable = true,
                        isCustom = true,
                    ),
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun updateAssistant(id: String, transform: (ChatMessage) -> ChatMessage) {
        mutableMessages.update { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    private fun saveOverrides() {
        val root = JSONObject()
        mutableOverrides.value.forEach { (modelId, overrides) ->
            val entry = JSONObject()
            overrides.contextSize?.let { entry.put("contextSize", it) }
            overrides.maxOutputTokens?.let { entry.put("maxOutputTokens", it) }
            overrides.temperature?.let { entry.put("temperature", it.toDouble()) }
            overrides.topP?.let { entry.put("topP", it.toDouble()) }
            overrides.topK?.let { entry.put("topK", it) }
            overrides.backend?.let { entry.put("backend", it) }
            overrides.showThinking?.let { entry.put("showThinking", it) }
            root.put(modelId, entry)
        }
        modelSettingsFile.writeText(root.toString())
    }

    private fun loadOverrides(): Map<String, ModelOverrides> = runCatching {
        if (!modelSettingsFile.isFile) return@runCatching emptyMap()
        val root = JSONObject(modelSettingsFile.readText())
        buildMap {
            root.keys().forEach { modelId ->
                val entry = root.getJSONObject(modelId)
                put(
                    modelId,
                    ModelOverrides(
                        contextSize = entry.optInt("contextSize").takeIf { entry.has("contextSize") },
                        maxOutputTokens = entry.optInt("maxOutputTokens").takeIf { entry.has("maxOutputTokens") },
                        temperature = entry.optDouble("temperature")
                            .takeIf { entry.has("temperature") }
                            ?.toFloat(),
                        topP = entry.optDouble("topP").takeIf { entry.has("topP") }?.toFloat(),
                        topK = entry.optInt("topK").takeIf { entry.has("topK") },
                        backend = entry.optString("backend").takeIf { entry.has("backend") },
                        showThinking = entry.optBoolean("showThinking").takeIf { entry.has("showThinking") },
                    ),
                )
            }
        }
    }.getOrDefault(emptyMap())

    private companion object {
        const val CUSTOM_IMPORT_ID = "__custom_import__"
        const val KEY_PRESET = "device_preset"
        const val KEY_BACKEND = "backend_pref"
        const val KEY_TEMPERATURE = "temperature"
        const val KEY_TOP_P = "top_p"
        const val KEY_TOP_K = "top_k"
        const val KEY_SYSTEM_PROMPT = "system_prompt"
        const val KEY_SHOW_THINKING = "show_thinking"
        const val KEY_MARKDOWN = "markdown"
    }

    override fun onCleared() {
        generationJob?.cancel()
        session?.close()
        activeEngine?.close()
        super.onCleared()
    }
}
