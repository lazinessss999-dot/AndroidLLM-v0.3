package app.androidllm.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp

/**
 * Lightweight Markdown renderer (no external dependencies).
 * Supports: headings, bold, italic, strikethrough, inline code, fenced code
 * blocks, unordered/ordered lists, blockquotes and links.
 */
@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    baseStyle: TextStyle = MaterialTheme.typography.bodyLarge,
    baseColor: Color = Color.Unspecified,
    codeColor: Color = MaterialTheme.colorScheme.tertiary,
    quoteColor: Color = MaterialTheme.colorScheme.primary,
) {
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }
    val codeBackground = MaterialTheme.colorScheme.surfaceVariant
    val linkColor = if (baseColor == Color.Unspecified) MaterialTheme.colorScheme.primary else baseColor
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Heading -> {
                    val headingStyle = when (block.level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    }
                    Text(
                        text = inlineAnnotated(block.text, baseColor, codeColor, codeBackground, linkColor),
                        style = headingStyle,
                    )
                }

                is MdBlock.Paragraph -> Text(
                    text = inlineAnnotated(block.text, baseColor, codeColor, codeBackground, linkColor),
                    style = baseStyle,
                )

                is MdBlock.CodeBlock -> Text(
                    text = block.code,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            codeBackground,
                            RoundedCornerShape(8.dp),
                        )
                        .padding(10.dp),
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                    ),
                    color = codeColor,
                )

                is MdBlock.Bullet -> Row {
                    Text(
                        text = "•  ",
                        style = baseStyle,
                        color = codeColor,
                    )
                    Text(
                        text = inlineAnnotated(block.text, baseColor, codeColor, codeBackground, linkColor),
                        style = baseStyle,
                    )
                }

                is MdBlock.Ordered -> Row {
                    Text(
                        text = "${block.index}. ",
                        style = baseStyle,
                        color = codeColor,
                    )
                    Text(
                        text = inlineAnnotated(block.text, baseColor, codeColor, codeBackground, linkColor),
                        style = baseStyle,
                    )
                }

                is MdBlock.Quote -> Text(
                    text = inlineAnnotated(block.text, baseColor, codeColor, codeBackground, linkColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            quoteColor.copy(alpha = 0.12f),
                            RoundedCornerShape(8.dp),
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    style = baseStyle,
                )
            }
        }
    }
}

private fun inlineAnnotated(
    text: String,
    baseColor: Color,
    codeColor: Color,
    codeBackground: Color,
    linkColor: Color,
): AnnotatedString = buildAnnotatedString {
    val spans = MarkdownParser.parseInline(text)
    spans.forEach { span ->
        when (span) {
            is MdSpan.Text -> append(span.value)
            is MdSpan.Code -> withStyle(
                SpanStyle(
                    fontFamily = FontFamily.Monospace,
                    color = codeColor,
                    background = codeBackground,
                ),
            ) { append(span.value) }

            is MdSpan.Bold -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }

            is MdSpan.Italic -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }

            is MdSpan.Strike -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }

            is MdSpan.Link -> withStyle(
                SpanStyle(
                    color = linkColor,
                    textDecoration = TextDecoration.Underline,
                ),
            ) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }
        }
    }
}

private fun androidx.compose.ui.text.AnnotatedString.Builder.appendInline(
    spans: List<MdSpan>,
    baseColor: Color,
    codeColor: Color,
    codeBackground: Color,
    linkColor: Color,
) {
    spans.forEach { span ->
        when (span) {
            is MdSpan.Text -> append(span.value)
            is MdSpan.Code -> withStyle(
                SpanStyle(
                    fontFamily = FontFamily.Monospace,
                    color = codeColor,
                    background = codeBackground,
                ),
            ) { append(span.value) }

            is MdSpan.Bold -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }

            is MdSpan.Italic -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }

            is MdSpan.Strike -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }

            is MdSpan.Link -> withStyle(
                SpanStyle(
                    color = linkColor,
                    textDecoration = TextDecoration.Underline,
                ),
            ) {
                appendInline(span.spans, baseColor, codeColor, codeBackground, linkColor)
            }
        }
    }
}

sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class CodeBlock(val code: String) : MdBlock
    data class Bullet(val text: String) : MdBlock
    data class Ordered(val index: Int, val text: String) : MdBlock
    data class Quote(val text: String) : MdBlock
}

sealed interface MdSpan {
    data class Text(val value: String) : MdSpan
    data class Code(val value: String) : MdSpan
    data class Bold(val spans: List<MdSpan>) : MdSpan
    data class Italic(val spans: List<MdSpan>) : MdSpan
    data class Strike(val spans: List<MdSpan>) : MdSpan
    data class Link(val spans: List<MdSpan>, val url: String) : MdSpan
}

object MarkdownParser {

    fun parse(markdown: String): List<MdBlock> {
        val lines = markdown.lines()
        val blocks = mutableListOf<MdBlock>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            when {
                line.isBlank() -> i++

                line.trimStart().startsWith("```") -> {
                    val code = StringBuilder()
                    i++
                    while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                        code.append(lines[i]).append('\n')
                        i++
                    }
                    if (i < lines.size) i++
                    blocks += MdBlock.CodeBlock(code.toString().trimEnd('\n'))
                }

                line.trimStart().startsWith(">") -> {
                    val quote = mutableListOf<String>()
                    while (i < lines.size && lines[i].trimStart().startsWith(">")) {
                        quote += lines[i].trimStart().removePrefix(">").trim()
                        i++
                    }
                    blocks += MdBlock.Quote(quote.joinToString(" "))
                }

                isHeading(line) != null -> {
                    val level = isHeading(line)!!
                    blocks += MdBlock.Heading(level, line.trimStart().substring(level).trim())
                    i++
                }

                else -> {
                    val group = mutableListOf<String>()
                    while (i < lines.size && lines[i].isNotBlank()) {
                        group += lines[i]
                        i++
                    }
                    blocks += parseGroup(group)
                }
            }
        }
        return blocks
    }

    private fun parseGroup(group: List<String>): List<MdBlock> {
        val first = group.first()
        val heading = first.takeWhile { it == '#' }
        if (heading.length in 1..6 && first.length > heading.length && first[heading.length] == ' ') {
            return listOf(
                MdBlock.Heading(
                    level = heading.length,
                    text = first.substring(heading.length).trim(),
                ),
            )
        }
        if (group.all { isBullet(it) }) {
            return group.map { MdBlock.Bullet(it.trimStart().substring(2).trim()) }
        }
        val ordered = parseOrdered(group)
        if (ordered != null) return ordered

        val quote = group.filter { it.trimStart().startsWith(">") }
        if (quote.size == group.size) {
            return listOf(MdBlock.Quote(quote.joinToString(" ") { it.trimStart().removePrefix(">").trim() }))
        }
        return listOf(MdBlock.Paragraph(group.joinToString(" ")))
    }

    private fun isHeading(line: String): Int? {
        val trimmed = line.trimStart()
        val level = trimmed.takeWhile { it == '#' }.length
        return if (level in 1..6 && trimmed.length > level && trimmed[level] == ' ') level else null
    }

    private fun isBullet(line: String): Boolean {
        val trimmed = line.trimStart()
        return trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("+ ")
    }

    private fun parseOrdered(group: List<String>): List<MdBlock>? {
        val indexed = group.mapIndexed { index, line ->
            val match = ORDERED_REGEX.matchEntire(line.trimStart()) ?: return null
            val number = match.groupValues[1].toIntOrNull() ?: (index + 1)
            number to match.groupValues[2]
        }
        return indexed.map { (number, text) -> MdBlock.Ordered(number, text) }
    }

    private val ORDERED_REGEX = Regex("""^(\d{1,3})[.)]\s+(.+)$""")

    fun parseInline(text: String): List<MdSpan> {
        val spans = mutableListOf<MdSpan>()
        val regex = Regex(
            "(`[^`]*`)" +
                "|(\\*\\*[^*]+\\*\\*)" +
                "|(\\*[^*]+\\*)" +
                "|(__[^_]+__)" +
                "|(_[^_]+_)" +
                "|(~~[^~]+~~)" +
                "|(\\[[^\\]]+\\]\\([^)]*\\))",
        )
        var last = 0
        regex.findAll(text).forEach { match ->
            if (match.range.first > last) {
                spans += MdSpan.Text(text.substring(last, match.range.first))
            }
            spans += parseToken(match.value)
            last = match.range.last + 1
        }
        if (last < text.length) {
            spans += MdSpan.Text(text.substring(last))
        }
        return spans
    }

    private fun parseToken(token: String): MdSpan = when {
        token.startsWith("`") && token.endsWith("`") && token.length >= 2 ->
            MdSpan.Code(token.substring(1, token.length - 1))

        token.startsWith("**") && token.endsWith("**") && token.length >= 4 ->
            MdSpan.Bold(parseInline(token.substring(2, token.length - 2)))

        token.startsWith("__") && token.endsWith("__") && token.length >= 4 ->
            MdSpan.Bold(parseInline(token.substring(2, token.length - 2)))

        token.startsWith("~~") && token.endsWith("~~") && token.length >= 4 ->
            MdSpan.Strike(parseInline(token.substring(2, token.length - 2)))

        token.startsWith("*") && token.endsWith("*") && token.length >= 2 ->
            MdSpan.Italic(parseInline(token.substring(1, token.length - 1)))

        token.startsWith("_") && token.endsWith("_") && token.length >= 2 ->
            MdSpan.Italic(parseInline(token.substring(1, token.length - 1)))

        token.startsWith("[") && token.endsWith(")") -> {
            val closeBracket = token.indexOf(']')
            val label = token.substring(1, closeBracket)
            val url = token.substring(closeBracket + 2, token.length - 1)
            MdSpan.Link(parseInline(label), url)
        }

        else -> MdSpan.Text(token)
    }
}
