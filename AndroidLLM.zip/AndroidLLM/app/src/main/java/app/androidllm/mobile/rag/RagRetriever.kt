package app.androidllm.mobile.rag

import app.androidllm.core.model.AttachedDocument

/**
 * Minimal offline retriever: splits attached documents into chunks and ranks
 * them by lexical overlap with the query (no embeddings, no network). Designed
 * for small local models and modest context windows.
 */
object RagRetriever {

    const val DEFAULT_MAX_CHARS = 1600
    const val DEFAULT_TOP_CHUNKS = 4
    const val MAX_FILE_BYTES = 2_000_000L

    fun retrieve(
        query: String,
        documents: List<AttachedDocument>,
        maxChars: Int = DEFAULT_MAX_CHARS,
        topChunks: Int = DEFAULT_TOP_CHUNKS,
    ): String {
        val queryTokens = tokenize(query).toSet()
        if (queryTokens.isEmpty() || documents.isEmpty()) return ""

        val scored = buildList {
            documents.forEach { doc ->
                chunk(doc.text).forEach { piece ->
                    val score = score(queryTokens, piece)
                    if (score > 0.0) add(ScoredChunk(piece, score))
                }
            }
        }.sortedByDescending { it.score }.take(topChunks)

        if (scored.isEmpty()) return ""

        val builder = StringBuilder()
        var used = 0
        for (chunk in scored) {
            val piece = chunk.text.trim()
            if (piece.isEmpty()) continue
            val remaining = maxChars - used
            if (remaining <= 40) break
            val cut = if (piece.length > remaining) {
                piece.take(remaining).substringBeforeLast(' ').ifBlank { piece.take(remaining) }
            } else {
                piece
            }
            builder.append(cut).append("\n\n")
            used += cut.length + 2
        }
        return builder.toString().trim()
    }

    fun chunk(text: String, target: Int = 900, overlap: Int = 120): List<String> {
        val cleaned = text.replace('\u0000', ' ').trim()
        if (cleaned.isEmpty()) return emptyList()

        val paragraphs = cleaned
            .split(Regex("\\n\\s*\\n"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val chunks = mutableListOf<String>()
        val current = StringBuilder()

        fun flush() {
            if (current.isNotBlank()) chunks += current.toString().trim()
            current.clear()
        }

        for (paragraph in paragraphs) {
            if (paragraph.length > target) {
                flush()
                chunks += splitLong(paragraph, target)
            } else {
                if (current.isNotEmpty() && current.length + paragraph.length + 2 > target) {
                    flush()
                    // keep a small tail for context continuity
                    val last = chunks.lastOrNull().orEmpty()
                    if (overlap > 0 && last.isNotEmpty()) {
                        current.append(last.takeLast(overlap).substringAfterLast('\n').trim())
                        if (current.isNotEmpty()) current.append(' ')
                    }
                }
                current.append(paragraph).append("\n\n")
            }
        }
        flush()
        return chunks.ifEmpty { listOf(cleaned.take(target)) }
    }

    private fun splitLong(text: String, target: Int): List<String> {
        val result = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            var end = (start + target).coerceAtMost(text.length)
            if (end < text.length) {
                val cut = text.lastIndexOf(' ', end)
                if (cut > start) end = cut
            }
            result += text.substring(start, end).trim()
            start = end
        }
        return result.filter { it.isNotEmpty() }
    }

    private fun score(queryTokens: Set<String>, chunkText: String): Double {
        val chunkTokens = tokenize(chunkText)
        if (chunkTokens.isEmpty()) return 0.0
        val chunkSet = chunkTokens.toSet()
        val overlap = queryTokens.count { it in chunkSet }
        if (overlap == 0) return 0.0
        return overlap.toDouble() / (1.0 + Math.log10(chunkSet.size.toDouble() + 1.0))
    }

    private fun tokenize(text: String): List<String> =
        text.lowercase()
            .split(Regex("[^\\p{L}\\p{N}_-]+"))
            .map { it.trim() }
            .filter { it.length > 1 }

    private data class ScoredChunk(val text: String, val score: Double)
}
