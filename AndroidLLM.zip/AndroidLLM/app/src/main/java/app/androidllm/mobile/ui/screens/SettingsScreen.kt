package app.androidllm.mobile.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.androidllm.core.model.DevicePreset
import app.androidllm.core.model.EngineType
import app.androidllm.core.model.GenerationConfig
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.ModelOverrides
import app.androidllm.mobile.R
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    contentPadding: PaddingValues,
    config: GenerationConfig,
    selectedModel: LocalModel?,
    backendPreference: String,
    activeBackend: String?,
    presetSelection: String,
    resolvedPreset: DevicePreset,
    detectedRamGb: Int,
    detectedCores: Int,
    modelOverrides: Map<String, ModelOverrides>,
    onBackendPreferenceChange: (String) -> Unit,
    onPresetSelectionChange: (String) -> Unit,
    onTemperatureChange: (Float) -> Unit,
    onTopPChange: (Float) -> Unit,
    onTopKChange: (Int) -> Unit,
    onShowThinkingChange: (Boolean) -> Unit,
    onMarkdownChange: (Boolean) -> Unit,
    onSystemPromptChange: (String) -> Unit,
    onModelContextChange: (Int) -> Unit,
    onModelMaxOutputChange: (Int) -> Unit,
    onModelTemperatureChange: (Float) -> Unit,
    onModelTopPChange: (Float) -> Unit,
    onModelTopKChange: (Int) -> Unit,
    onModelBackendChange: (String) -> Unit,
    onModelShowThinkingChange: (Boolean) -> Unit,
    onResetModelSettings: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
    ) {
        TopAppBar(title = { Text(stringResource(R.string.settings_title)) })
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsCard {
                SectionTitle(stringResource(R.string.performance_section))
                Text(
                    text = stringResource(R.string.detected_ram, detectedRamGb, detectedCores),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    presetChoices().forEach { (key, label) ->
                        FilterChip(
                            selected = presetSelection == key,
                            onClick = { onPresetSelectionChange(key) },
                            label = { Text(label) },
                        )
                    }
                }
                Text(
                    text = stringResource(
                        R.string.preset_description,
                        resolvedPreset.contextSize,
                        resolvedPreset.maxOutputTokens,
                        resolvedPreset.backend,
                    ),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    stringResource(R.string.performance_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SettingsCard {
                SectionTitle(stringResource(R.string.runtime_section))
                if (selectedModel != null) {
                    Text(selectedModel.displayName, color = MaterialTheme.colorScheme.primary)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("CPU", "AUTO", "GPU").forEach { backend ->
                        FilterChip(
                            selected = backendPreference == backend,
                            onClick = { onBackendPreferenceChange(backend) },
                            label = { Text(backend) },
                        )
                    }
                }
                Text(
                    text = stringResource(
                        R.string.active_backend,
                        when (activeBackend) {
                            "CPU_FALLBACK" -> stringResource(R.string.backend_cpu_fallback)
                            "LLAMA_CPU" -> "llama.cpp CPU"
                            null -> stringResource(R.string.backend_not_loaded)
                            else -> activeBackend
                        },
                    ),
                    style = MaterialTheme.typography.labelLarge,
                )
                Text(
                    stringResource(R.string.gpu_experimental_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    stringResource(R.string.runtime_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SettingsCard {
                SectionTitle(stringResource(R.string.generation_section))
                CommitSlider(
                    label = stringResource(R.string.temperature_label),
                    value = config.temperature,
                    valueRange = 0f..2f,
                    valueText = { stringResource(R.string.temperature_value, it) },
                    onCommit = onTemperatureChange,
                )
                CommitSlider(
                    label = stringResource(R.string.top_p_label),
                    value = config.topP,
                    valueRange = 0.05f..1f,
                    valueText = { stringResource(R.string.top_p_value, it) },
                    onCommit = onTopPChange,
                )
                CommitSlider(
                    label = stringResource(R.string.top_k_label),
                    value = config.topK.toFloat(),
                    valueRange = 1f..100f,
                    steps = 98,
                    valueText = { stringResource(R.string.top_k_value, it.roundToInt()) },
                    onCommit = { onTopKChange(it.roundToInt()) },
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(stringResource(R.string.show_thinking), modifier = Modifier.weight(1f))
                    Switch(
                        checked = config.showThinking,
                        onCheckedChange = onShowThinkingChange,
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.markdown_title))
                        Text(
                            stringResource(R.string.markdown_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = config.renderMarkdown,
                        onCheckedChange = onMarkdownChange,
                    )
                }
                OutlinedTextField(
                    value = config.systemPrompt,
                    onValueChange = onSystemPromptChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.system_prompt)) },
                    placeholder = { Text(stringResource(R.string.system_prompt_hint)) },
                    minLines = 3,
                )
            }

            if (selectedModel != null) {
                val modelId = selectedModel.id
                val overrides = modelOverrides[modelId]
                val effectiveContext = overrides?.contextSize ?: resolvedPreset.contextSize
                val effectiveMaxOutput = overrides?.maxOutputTokens ?: resolvedPreset.maxOutputTokens
                val effectiveTemperature = overrides?.temperature ?: config.temperature
                val effectiveTopP = overrides?.topP ?: config.topP
                val effectiveTopK = overrides?.topK ?: config.topK
                val effectiveThinking = overrides?.showThinking ?: config.showThinking
                val effectiveBackend = overrides?.backend ?: backendPreference

                SettingsCard {
                    SectionTitle(stringResource(R.string.model_section, selectedModel.displayName))
                    Text(
                        stringResource(R.string.model_section_note),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    CommitSlider(
                        label = stringResource(R.string.context_size_label),
                        value = effectiveContext.toFloat(),
                        valueRange = 512f..4096f,
                        steps = 13,
                        valueText = { stringResource(R.string.context_size_value, it.roundToInt()) },
                        onCommit = { onModelContextChange(it.roundToInt()) },
                    )
                    CommitSlider(
                        label = stringResource(R.string.max_output),
                        value = effectiveMaxOutput.toFloat(),
                        valueRange = 128f..2048f,
                        steps = 14,
                        valueText = { stringResource(R.string.max_output_value, it.roundToInt()) },
                        onCommit = { onModelMaxOutputChange(it.roundToInt()) },
                    )
                    CommitSlider(
                        label = stringResource(R.string.temperature_label),
                        value = effectiveTemperature,
                        valueRange = 0f..2f,
                        valueText = { stringResource(R.string.temperature_value, it) },
                        onCommit = { onModelTemperatureChange(it) },
                    )
                    CommitSlider(
                        label = stringResource(R.string.top_p_label),
                        value = effectiveTopP,
                        valueRange = 0.05f..1f,
                        valueText = { stringResource(R.string.top_p_value, it) },
                        onCommit = { onModelTopPChange(it) },
                    )
                    CommitSlider(
                        label = stringResource(R.string.top_k_label),
                        value = effectiveTopK.toFloat(),
                        valueRange = 1f..100f,
                        steps = 98,
                        valueText = { stringResource(R.string.top_k_value, it.roundToInt()) },
                        onCommit = { onModelTopKChange(it.roundToInt()) },
                    )
                    if (selectedModel.engineType == EngineType.LITERT) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf("CPU", "AUTO", "GPU").forEach { backend ->
                                FilterChip(
                                    selected = effectiveBackend == backend,
                                    onClick = { onModelBackendChange(backend) },
                                    label = { Text(backend) },
                                )
                            }
                        }
                    } else {
                        Text(
                            stringResource(R.string.gguf_cpu_only),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            stringResource(R.string.show_thinking),
                            modifier = Modifier.weight(1f),
                        )
                        Switch(
                            checked = effectiveThinking,
                            onCheckedChange = { onModelShowThinkingChange(it) },
                        )
                    }
                    OutlinedButton(
                        onClick = { onResetModelSettings() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = overrides != null,
                    ) {
                        Text(stringResource(R.string.reset_model_settings))
                    }
                }
            }

            SettingsCard {
                SectionTitle(stringResource(R.string.privacy_section))
                Text(
                    stringResource(R.string.privacy_note),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun presetLabel(preset: DevicePreset): String = when (preset) {
    DevicePreset.LOW -> stringResource(R.string.preset_low)
    DevicePreset.MEDIUM -> stringResource(R.string.preset_medium)
    DevicePreset.HIGH -> stringResource(R.string.preset_high)
    DevicePreset.FLAGSHIP -> stringResource(R.string.preset_flagship)
}

@Composable
private fun presetChoices(): List<Pair<String, String>> = listOf(
    DevicePreset.AUTO to stringResource(R.string.preset_auto),
    DevicePreset.LOW.name to stringResource(R.string.preset_low),
    DevicePreset.MEDIUM.name to stringResource(R.string.preset_medium),
    DevicePreset.HIGH.name to stringResource(R.string.preset_high),
    DevicePreset.FLAGSHIP.name to stringResource(R.string.preset_flagship),
)

@Composable
private fun CommitSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    valueText: @Composable (Float) -> String,
    onCommit: (Float) -> Unit,
) {
    var current by remember(value) { mutableFloatStateOf(value) }
    LaunchedEffect(value) { current = value }
    Text(valueText(current))
    Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Slider(
        value = current,
        onValueChange = { current = it },
        onValueChangeFinished = { onCommit(current) },
        valueRange = valueRange,
        steps = steps,
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content,
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
    )
}
