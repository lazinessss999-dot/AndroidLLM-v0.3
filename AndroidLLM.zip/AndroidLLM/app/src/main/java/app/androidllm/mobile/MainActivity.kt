package app.androidllm.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import app.androidllm.mobile.ui.AndroidLlmApp
import app.androidllm.mobile.ui.theme.AndroidLlmTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            AndroidLlmTheme {
                AndroidLlmApp()
            }
        }
    }
}
