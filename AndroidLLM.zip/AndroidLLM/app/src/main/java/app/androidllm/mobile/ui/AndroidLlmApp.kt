package app.androidllm.mobile.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import app.androidllm.mobile.R
import app.androidllm.mobile.ui.screens.ChatScreen
import app.androidllm.mobile.ui.screens.ModelsScreen
import app.androidllm.mobile.ui.screens.SettingsScreen

enum class AppDestination(
    val route: String,
    @StringRes val label: Int,
    val glyph: String,
) {
    MODELS("models", R.string.nav_models, "◫"),
    CHAT("chat", R.string.nav_chat, "◆"),
    SETTINGS("settings", R.string.nav_settings, "⚙"),
}

@Composable
fun AndroidLlmApp(viewModel: AndroidLlmViewModel = viewModel()) {
    val navController = rememberNavController()
    val models by viewModel.models.collectAsStateWithLifecycle()
    val importStatus by viewModel.importStatus.collectAsStateWithLifecycle()
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val attachment by viewModel.attachment.collectAsStateWithLifecycle()
    val documents by viewModel.documents.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val config by viewModel.config.collectAsStateWithLifecycle()
    val backendPreference by viewModel.backendPreference.collectAsStateWithLifecycle()
    val activeBackend by viewModel.activeBackend.collectAsStateWithLifecycle()
    val presetSelection by viewModel.presetSelection.collectAsStateWithLifecycle()
    val resolvedPreset by viewModel.resolvedPreset.collectAsStateWithLifecycle()
    val modelOverrides by viewModel.modelOverrides.collectAsStateWithLifecycle()
    val error by viewModel.error.collectAsStateWithLifecycle()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar {
                AppDestination.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Text(destination.glyph) },
                        label = { Text(stringResource(destination.label)) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = AppDestination.MODELS.route,
        ) {
            composable(AppDestination.MODELS.route) {
                ModelsScreen(
                    contentPadding = padding,
                    models = models,
                    selectedModel = selectedModel,
                    engineState = engineState,
                    importStatus = importStatus,
                    error = error,
                    deviceInfo = viewModel.deviceInfo,
                    resolvedPreset = resolvedPreset,
                    onImport = viewModel::importModel,
                    onImportCustom = viewModel::importCustomModel,
                    onDismissImportError = viewModel::clearImportError,
                    onSelect = viewModel::selectModel,
                    onOpenChat = { navController.navigate(AppDestination.CHAT.route) },
                )
            }
            composable(AppDestination.CHAT.route) {
                ChatScreen(
                    contentPadding = padding,
                    selectedModel = selectedModel,
                    messages = messages,
                    attachment = attachment,
                    documents = documents,
                    isGenerating = isGenerating,
                    metrics = metrics,
                    error = error,
                    renderMarkdown = config.renderMarkdown,
                    onAttachImage = viewModel::attachImage,
                    onRemoveAttachment = viewModel::removeAttachment,
                    onAttachDocument = viewModel::attachDocument,
                    onRemoveDocument = viewModel::removeDocument,
                    onSend = viewModel::sendMessage,
                    onStop = viewModel::stopGeneration,
                    onClear = viewModel::clearChat,
                    onChooseModel = { navController.navigate(AppDestination.MODELS.route) },
                )
            }
            composable(AppDestination.SETTINGS.route) {
                val selectedId = selectedModel?.id
                SettingsScreen(
                    contentPadding = padding,
                    config = config,
                    selectedModel = selectedModel,
                    backendPreference = backendPreference,
                    activeBackend = activeBackend,
                    presetSelection = presetSelection,
                    resolvedPreset = resolvedPreset,
                    detectedRamGb = viewModel.deviceInfo.ramGb,
                    detectedCores = viewModel.deviceInfo.cores,
                    modelOverrides = modelOverrides,
                    onBackendPreferenceChange = viewModel::setBackendPreference,
                    onPresetSelectionChange = viewModel::setDevicePreset,
                    onTemperatureChange = viewModel::setTemperature,
                    onTopPChange = viewModel::setTopP,
                    onTopKChange = viewModel::setTopK,
                    onShowThinkingChange = viewModel::setShowThinking,
                    onMarkdownChange = viewModel::setMarkdown,
                    onSystemPromptChange = viewModel::setSystemPrompt,
                    onModelContextChange = { value -> selectedId?.let { viewModel.setModelContextSize(it, value) } },
                    onModelMaxOutputChange = { value -> selectedId?.let { viewModel.setModelMaxOutputTokens(it, value) } },
                    onModelTemperatureChange = { value -> selectedId?.let { viewModel.setModelTemperature(it, value) } },
                    onModelTopPChange = { value -> selectedId?.let { viewModel.setModelTopP(it, value) } },
                    onModelTopKChange = { value -> selectedId?.let { viewModel.setModelTopK(it, value) } },
                    onModelBackendChange = { value -> selectedId?.let { viewModel.setModelBackend(it, value) } },
                    onModelShowThinkingChange = { value -> selectedId?.let { viewModel.setModelShowThinking(it, value) } },
                    onResetModelSettings = { selectedId?.let { viewModel.resetModelOverrides(it) } },
                )
            }
        }
    }
}
