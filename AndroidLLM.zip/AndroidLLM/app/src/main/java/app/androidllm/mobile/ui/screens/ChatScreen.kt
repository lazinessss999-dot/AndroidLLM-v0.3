package app.androidllm.mobile.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.androidllm.core.inference.InferenceMetrics
import app.androidllm.core.model.AttachedDocument
import app.androidllm.core.model.ChatMessage
import app.androidllm.core.model.ChatRole
import app.androidllm.core.model.ImageAttachment
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.Modality
import app.androidllm.mobile.R
import app.androidllm.mobile.ui.MarkdownText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    contentPadding: PaddingValues,
    selectedModel: LocalModel?,
    messages: List<ChatMessage>,
    attachment: ImageAttachment?,
    documents: List<AttachedDocument>,
    isGenerating: Boolean,
    metrics: InferenceMetrics?,
    error: String?,
    renderMarkdown: Boolean,
    onAttachImage: (String) -> Unit,
    onRemoveAttachment: () -> Unit,
    onAttachDocument: (String) -> Unit,
    onRemoveDocument: (String) -> Unit,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onClear: () -> Unit,
    onChooseModel: () -> Unit,
) {
    var input by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            onAttachImage(uri.toString())
        }
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            onAttachDocument(uri.toString())
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
    ) {
        TopAppBar(
            title = {
                Column {
                    Text(stringResource(R.string.chat_title))
                    if (selectedModel != null) {
                        Text(selectedModel.displayName, style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            actions = {
                if (messages.isNotEmpty()) {
                    TextButton(onClick = onClear) { Text(stringResource(R.string.clear_chat)) }
                }
            },
        )

        if (selectedModel == null) {
            EmptyChat(onChooseModel)
            return@Column
        }

        val listState = rememberLazyListState()
        LaunchedEffect(messages.size, messages.lastOrNull()?.text) {
            if (messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (messages.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_messages),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(messages, key = ChatMessage::id) { message ->
                MessageBubble(message, renderMarkdown)
            }
            if (error != null) {
                item {
                    Text(
                        text = stringResource(R.string.engine_error, error),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }

        if (metrics != null) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AssistChip(onClick = {}, label = {
                    Text(stringResource(R.string.ttft, metrics.timeToFirstTokenMs))
                })
                AssistChip(onClick = {}, label = {
                    Text(stringResource(R.string.tokens_per_second, metrics.tokensPerSecond))
                })
            }
        }

        if (attachment != null) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AssistChip(onClick = {}, label = { Text(stringResource(R.string.image_attached)) })
                TextButton(onClick = onRemoveAttachment) {
                    Text(stringResource(R.string.remove_attachment))
                }
            }
        }

        if (documents.isNotEmpty()) {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = stringResource(R.string.documents_count, documents.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                documents.forEach { document ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        AssistChip(
                            onClick = {},
                            label = { Text(document.name, maxLines = 1) },
                        )
                        TextButton(onClick = { onRemoveDocument(document.id) }) {
                            Text("✕")
                        }
                    }
                }
                Text(
                    text = stringResource(R.string.rag_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (Modality.IMAGE in selectedModel.modalities) {
                OutlinedButton(
                    onClick = { imagePicker.launch(arrayOf("image/*")) },
                    enabled = !isGenerating,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                ) { Text("＋") }
            }
            OutlinedButton(
                onClick = {
                    documentPicker.launch(
                        arrayOf("text/*", "application/octet-stream", "application/json", "*/*"),
                    )
                },
                enabled = !isGenerating,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
            ) { Text("📎") }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.message_hint)) },
                enabled = !isGenerating,
                maxLines = 5,
            )
            if (isGenerating) {
                Button(onClick = onStop) { Text(stringResource(R.string.stop)) }
            } else {
                Button(
                    onClick = {
                        onSend(input)
                        input = ""
                    },
                    enabled = input.isNotBlank(),
                ) { Text(stringResource(R.string.send)) }
            }
        }
    }
}

@Composable
private fun EmptyChat(onChooseModel: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            stringResource(R.string.choose_model_first),
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onChooseModel) { Text(stringResource(R.string.go_to_models)) }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, renderMarkdown: Boolean) {
    val fromUser = message.role == ChatRole.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(if (fromUser) 0.82f else 0.94f),
            shape = RoundedCornerShape(
                topStart = 22.dp,
                topEnd = 22.dp,
                bottomStart = if (fromUser) 22.dp else 6.dp,
                bottomEnd = if (fromUser) 6.dp else 22.dp,
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (fromUser) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
            ),
        ) {
            Column(Modifier.padding(14.dp)) {
                if (message.images.isNotEmpty()) {
                    Text(
                        text = stringResource(R.string.image_attached),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(Modifier.height(6.dp))
                }
                if (message.thinking.isNotBlank()) {
                    Text(
                        text = stringResource(R.string.thinking),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                    Text(
                        text = message.thinking,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                }
                if (renderMarkdown && message.text.isNotBlank()) {
                    MarkdownText(markdown = message.text)
                } else {
                    Text(
                        text = if (message.text.isBlank() && message.isStreaming) "…" else message.text,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }
    }
}
