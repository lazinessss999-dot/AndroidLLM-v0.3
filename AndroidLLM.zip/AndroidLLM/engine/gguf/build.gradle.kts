plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
}

// Native (llama.cpp) build is driven by the presence of third_party/llama.cpp:
//  - run scripts/setup_llama_cpp.sh to clone the pinned llama.cpp revision and
//    build libai-chat.so from source via CMake;
//  - without that directory the module simply packages the prebuilt .so files
//    from src/main/jniLibs (produced by a previous native build). This keeps
//    ordinary app builds fast and memory-friendly.
val llamaCppDir = rootProject.file("third_party/llama.cpp")
val useNativeBuild = llamaCppDir.isDirectory

android {
    namespace = "app.androidllm.engine.gguf"
    compileSdk {
        version = release(37) {
            minorApiLevel = 0
        }
    }

    ndkVersion = "29.0.13113456"

    defaultConfig {
        minSdk = 31
        consumerProguardFiles("consumer-rules.pro")

        ndk {
            abiFilters += "arm64-v8a"
        }
        if (useNativeBuild) {
            externalNativeBuild {
                cmake {
                    arguments += "-DLLAMA_CPP_DIR=${llamaCppDir.absolutePath}"
                    arguments += "-DCMAKE_BUILD_TYPE=Release"
                    arguments += "-DBUILD_SHARED_LIBS=OFF"
                    arguments += "-DLLAMA_BUILD_APP=OFF"
                    arguments += "-DLLAMA_BUILD_COMMON=ON"
                    arguments += "-DLLAMA_OPENSSL=OFF"
                    arguments += "-DGGML_NATIVE=OFF"
                    arguments += "-DGGML_BACKEND_DL=OFF"
                    arguments += "-DGGML_CPU_ALL_VARIANTS=OFF"
                    arguments += "-DGGML_LLAMAFILE=OFF"
                }
            }
        }
    }

    if (useNativeBuild) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.31.6"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation(project(":core:model"))
    implementation(project(":core:inference-api"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.kotlinx.coroutines.android)
}
