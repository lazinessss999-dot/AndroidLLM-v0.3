package app.androidllm.engine.gguf

import android.content.Context
import app.androidllm.core.inference.ChatRequest
import app.androidllm.core.inference.ChatSession
import app.androidllm.core.inference.EngineCapabilities
import app.androidllm.core.inference.EngineState
import app.androidllm.core.inference.GenerationEvent
import app.androidllm.core.inference.InferenceEngine
import app.androidllm.core.inference.InferenceMetrics
import app.androidllm.core.inference.LoadOptions
import app.androidllm.core.inference.SessionConfig
import app.androidllm.core.model.EngineType
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.Modality
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine.State
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class GgufInferenceEngine(context: Context) : InferenceEngine {
    private val nativeEngine = AiChat.getInferenceEngine(context.applicationContext)
    private val mutableState = MutableStateFlow<EngineState>(EngineState.Idle)
    private val mutableActiveBackend = MutableStateFlow<String?>(null)
    private var loadedModel: LocalModel? = null
    private var loadOptions = LoadOptions(contextSize = 2048)

    override val state = mutableState.asStateFlow()
    override val activeBackend = mutableActiveBackend.asStateFlow()

    override val capabilities = EngineCapabilities(
        engineType = EngineType.GGUF,
        modalities = setOf(Modality.TEXT),
        supportsStop = true,
        supportsThinking = false,
        backends = setOf("CPU"),
    )

    override suspend fun load(model: LocalModel, options: LoadOptions) {
        require(model.engineType == EngineType.GGUF) { "llama.cpp requires a .gguf model" }
        require(Modality.IMAGE !in model.modalities) {
            "GGUF VLM requires an mmproj/mtmd adapter that is not enabled in this build"
        }
        val file = File(model.location)
        require(file.isFile && file.canRead()) { "GGUF model file is not readable" }

        mutableState.value = EngineState.Loading(model.id, "CPU")
        withContext(Dispatchers.IO) {
            awaitNativeInitialization()
            when (nativeEngine.state.value) {
                State.ModelReady, is State.Error -> runCatching { nativeEngine.cleanUp() }
                else -> Unit
            }
            nativeEngine.loadModel(
                pathToModel = file.absolutePath,
                contextSize = options.contextSize.coerceIn(512, 8192),
                temperature = 0.7f,
            )
        }
        loadedModel = model
        loadOptions = options.copy(backend = "CPU")
        mutableActiveBackend.value = "LLAMA_CPU"
        mutableState.value = EngineState.Ready(model.id, "LLAMA_CPU")
    }

    override suspend fun createSession(config: SessionConfig): ChatSession {
        val model = checkNotNull(loadedModel) { "Load a GGUF model first" }
        val prompt = config.generation.systemPrompt
        if (prompt.isNotBlank()) {
            withContext(Dispatchers.IO) { nativeEngine.setSystemPrompt(prompt) }
        }
        return GgufChatSession(
            nativeEngine = nativeEngine,
            model = model,
            loadOptions = loadOptions,
            config = config,
        )
    }

    override suspend fun unload() {
        withContext(Dispatchers.IO) {
            when (nativeEngine.state.value) {
                State.ModelReady, is State.Error -> runCatching { nativeEngine.cleanUp() }
                else -> Unit
            }
        }
        loadedModel = null
        mutableActiveBackend.value = null
        mutableState.value = EngineState.Idle
    }

    override fun close() {
        runCatching {
            when (nativeEngine.state.value) {
                State.ModelReady, is State.Error -> nativeEngine.cleanUp()
                else -> Unit
            }
        }
        loadedModel = null
        mutableActiveBackend.value = null
        mutableState.value = EngineState.Idle
    }

    private suspend fun awaitNativeInitialization() {
        val state = withTimeout(60_000) {
            nativeEngine.state
                .filter { it !is State.Uninitialized && it !is State.Initializing }
                .first()
        }
        if (state is State.Error) throw state.exception
    }
}

private class GgufChatSession(
    private val nativeEngine: com.arm.aichat.InferenceEngine,
    private val model: LocalModel,
    private val loadOptions: LoadOptions,
    private val config: SessionConfig,
) : ChatSession {
    private val closed = AtomicBoolean(false)

    override fun generate(request: ChatRequest): Flow<GenerationEvent> = flow {
        check(!closed.get()) { "GGUF session is closed" }
        require(request.images.isEmpty()) { "Image input is not yet available for GGUF models" }

        val startedAt = System.nanoTime()
        var firstTokenAt = 0L
        var tokenPieces = 0
        emit(GenerationEvent.Started)
        nativeEngine.sendUserPrompt(
            message = request.text,
            predictLength = config.generation.maxOutputTokens,
        ).collect { piece ->
            if (firstTokenAt == 0L) firstTokenAt = System.nanoTime()
            if (piece.isNotEmpty()) {
                tokenPieces += 1
                emit(GenerationEvent.TextDelta(piece))
            }
        }
        val completedAt = System.nanoTime()
        val totalMs = ((completedAt - startedAt) / 1_000_000).coerceAtLeast(1)
        val ttft = if (firstTokenAt == 0L) totalMs else (firstTokenAt - startedAt) / 1_000_000
        emit(
            GenerationEvent.Metrics(
                InferenceMetrics(
                    timeToFirstTokenMs = ttft,
                    generatedTokens = tokenPieces,
                    tokensPerSecond = tokenPieces * 1_000.0 / totalMs,
                    totalTimeMs = totalMs,
                ),
            ),
        )
        emit(GenerationEvent.Completed)
    }

    override suspend fun stop() {
        nativeEngine.stopGeneration()
    }

    override suspend fun reset() {
        withContext(Dispatchers.IO) {
            nativeEngine.stopGeneration()
            nativeEngine.cleanUp()
            nativeEngine.loadModel(
                pathToModel = model.location,
                contextSize = loadOptions.contextSize,
                temperature = config.generation.temperature,
            )
            config.generation.systemPrompt
                .takeIf(String::isNotBlank)
                ?.let { nativeEngine.setSystemPrompt(it) }
        }
    }

    override fun close() {
        closed.set(true)
        nativeEngine.stopGeneration()
    }
}
