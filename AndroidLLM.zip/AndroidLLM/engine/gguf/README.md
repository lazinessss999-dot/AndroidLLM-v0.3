# GGUF / llama.cpp adapter

Planned native runtime module for stage 3.

The integration will use a pinned `ggml-org/llama.cpp` git submodule and an Android JNI
adapter. The official `examples/llama.android/lib` currently declares minSdk 33, so the
first native task is an API 31 compatibility build and physical Android 12 test.
No prebuilt third-party APK is used.
