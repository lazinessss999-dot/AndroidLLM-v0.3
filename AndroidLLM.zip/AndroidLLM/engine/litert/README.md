# LiteRT-LM adapter

Real runtime adapter backed by `com.google.ai.edge.litertlm:litertlm-android:0.16.1`.

- Android 12+ / arm64-v8a
- CPU-first defaults for Unisoc T7250
- Text streaming
- Image input via resized PNG bytes
- Stop/reset/session lifecycle
- TTFT and approximate token-rate metrics

Models are downloaded from public Hugging Face links and imported through Android's document picker into app-private storage before loading.
