package app.androidllm.engine.litert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import app.androidllm.core.inference.ChatRequest
import app.androidllm.core.inference.ChatSession
import app.androidllm.core.inference.EngineCapabilities
import app.androidllm.core.inference.EngineState
import app.androidllm.core.inference.GenerationEvent
import app.androidllm.core.inference.InferenceEngine
import app.androidllm.core.inference.InferenceMetrics
import app.androidllm.core.inference.LoadOptions
import app.androidllm.core.inference.SessionConfig
import app.androidllm.core.model.EngineType
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.Modality
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext

class LiteRtInferenceEngine(
    context: Context,
) : InferenceEngine {
    private val appContext = context.applicationContext
    private val mutableState = MutableStateFlow<EngineState>(EngineState.Idle)
    private val mutableActiveBackend = MutableStateFlow<String?>(null)
    private var engine: Engine? = null
    private var loadedModel: LocalModel? = null

    override val state = mutableState.asStateFlow()
    override val activeBackend = mutableActiveBackend.asStateFlow()

    override val capabilities = EngineCapabilities(
        engineType = EngineType.LITERT,
        modalities = setOf(Modality.TEXT, Modality.IMAGE),
        supportsStop = true,
        supportsThinking = true,
        backends = setOf("AUTO", "CPU", "GPU"),
    )

    override suspend fun load(model: LocalModel, options: LoadOptions) {
        require(model.engineType == EngineType.LITERT) { "LiteRT-LM requires a .litertlm model" }
        val modelFile = File(model.location)
        require(modelFile.isFile && modelFile.canRead()) { "Model file is not readable" }

        val requested = options.backend.uppercase()
        val candidates = when (requested) {
            "AUTO" -> listOf("GPU", "CPU")
            "GPU" -> listOf("GPU")
            else -> listOf("CPU")
        }
        mutableState.value = EngineState.Loading(model.id, requested)
        withContext(Dispatchers.IO) {
            closeEngine()
            var lastFailure: Throwable? = null
            for (candidate in candidates) {
                val backend = if (candidate == "GPU") Backend.GPU() else Backend.CPU()
                val config = EngineConfig(
                    modelPath = modelFile.absolutePath,
                    backend = backend,
                    visionBackend = if (Modality.IMAGE in model.modalities) backend else null,
                    maxNumTokens = options.contextSize,
                    cacheDir = appContext.cacheDir.absolutePath,
                )
                val candidateEngine = Engine(config)
                try {
                    candidateEngine.initialize()
                    engine = candidateEngine
                    loadedModel = model
                    mutableActiveBackend.value = when {
                        requested == "AUTO" && candidate == "CPU" -> "CPU_FALLBACK"
                        else -> candidate
                    }
                    lastFailure = null
                    break
                } catch (throwable: Throwable) {
                    lastFailure = throwable
                    runCatching { candidateEngine.close() }
                }
            }
            if (engine == null) throw checkNotNull(lastFailure)
        }
        val resolved = mutableActiveBackend.value ?: "CPU"
        mutableState.value = EngineState.Ready(model.id, resolved)
    }

    override suspend fun createSession(config: SessionConfig): ChatSession {
        val activeEngine = checkNotNull(engine) { "Load a model before creating a session" }
        val activeModel = checkNotNull(loadedModel)
        return LiteRtChatSession(
            context = appContext,
            engine = activeEngine,
            model = activeModel,
            config = config,
        )
    }

    override suspend fun unload() {
        withContext(Dispatchers.IO) { closeEngine() }
        mutableState.value = EngineState.Idle
    }

    override fun close() {
        closeEngine()
        mutableState.value = EngineState.Idle
    }

    private fun closeEngine() {
        runCatching { engine?.close() }
        engine = null
        loadedModel = null
        mutableActiveBackend.value = null
    }
}

private class LiteRtChatSession(
    private val context: Context,
    private val engine: Engine,
    private val model: LocalModel,
    private val config: SessionConfig,
) : ChatSession {
    private var conversation: Conversation = createConversation()
    private val closed = AtomicBoolean(false)

    override fun generate(request: ChatRequest): Flow<GenerationEvent> = flow {
        check(!closed.get()) { "Conversation is closed" }
        val contents = withContext(Dispatchers.IO) { createContents(request) }
        emitAll(stream(contents))
    }

    override suspend fun stop() {
        runCatching { conversation.cancelProcess() }
    }

    override suspend fun reset() {
        withContext(Dispatchers.IO) {
            runCatching { conversation.cancelProcess() }
            runCatching { conversation.close() }
            conversation = createConversation()
        }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            runCatching { conversation.cancelProcess() }
            runCatching { conversation.close() }
        }
    }

    private fun createConversation(): Conversation {
        val generation = config.generation
        val systemInstruction = generation.systemPrompt
            .takeIf(String::isNotBlank)
            ?.let { Contents.of(Content.Text(it)) }
        return engine.createConversation(
            ConversationConfig(
                samplerConfig = SamplerConfig(
                    topK = generation.topK,
                    topP = generation.topP.toDouble(),
                    temperature = generation.temperature.toDouble(),
                ),
                systemInstruction = systemInstruction,
            ),
        )
    }

    private fun stream(contents: Contents): Flow<GenerationEvent> = callbackFlow {
        val startedAt = System.nanoTime()
        val firstTokenAt = AtomicLong(0L)
        val tokenEstimate = AtomicInteger(0)
        trySend(GenerationEvent.Started)

        conversation.sendMessageAsync(
            contents,
            object : MessageCallback {
                override fun onMessage(message: Message) {
                    val now = System.nanoTime()
                    firstTokenAt.compareAndSet(0L, now)
                    val text = message.toString()
                    if (text.isNotEmpty()) {
                        tokenEstimate.addAndGet(estimateTokens(text))
                        trySend(GenerationEvent.TextDelta(text))
                    }
                    message.channels[THOUGHT_CHANNEL]
                        ?.takeIf(String::isNotEmpty)
                        ?.let { trySend(GenerationEvent.ThinkingDelta(it)) }
                }

                override fun onDone() {
                    val completedAt = System.nanoTime()
                    val totalMs = ((completedAt - startedAt) / 1_000_000).coerceAtLeast(1)
                    val first = firstTokenAt.get()
                    val ttftMs = if (first == 0L) totalMs else (first - startedAt) / 1_000_000
                    val tokens = tokenEstimate.get()
                    trySend(
                        GenerationEvent.Metrics(
                            InferenceMetrics(
                                timeToFirstTokenMs = ttftMs,
                                generatedTokens = tokens,
                                tokensPerSecond = tokens * 1_000.0 / totalMs,
                                totalTimeMs = totalMs,
                            ),
                        ),
                    )
                    trySend(GenerationEvent.Completed)
                    close()
                }

                override fun onError(throwable: Throwable) {
                    close(throwable)
                }
            },
            mapOf("enable_thinking" to config.generation.showThinking),
        )

        awaitClose { runCatching { conversation.cancelProcess() } }
    }

    private fun createContents(request: ChatRequest): Contents {
        val contents = buildList {
            if (Modality.IMAGE in model.modalities) {
                request.images.forEach { attachment ->
                    add(Content.ImageBytes(readScaledPng(Uri.parse(attachment.uri))))
                }
            }
            add(Content.Text(request.text))
        }
        return Contents.of(contents)
    }

    private fun readScaledPng(uri: Uri): ByteArray {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open image" }
            BitmapFactory.decodeStream(input, null, bounds)
        }
        val sample = calculateSample(bounds.outWidth, bounds.outHeight, MAX_IMAGE_EDGE)
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open image" }
            BitmapFactory.decodeStream(input, null, options)
        } ?: error("Unsupported image")

        val scaled = scaleDown(decoded, MAX_IMAGE_EDGE)
        return ByteArrayOutputStream().use { output ->
            check(scaled.compress(Bitmap.CompressFormat.PNG, 100, output))
            if (scaled !== decoded) scaled.recycle()
            decoded.recycle()
            output.toByteArray()
        }
    }

    private fun scaleDown(source: Bitmap, maxEdge: Int): Bitmap {
        val edge = maxOf(source.width, source.height)
        if (edge <= maxEdge) return source
        val scale = maxEdge.toFloat() / edge
        return Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true,
        )
    }

    private fun calculateSample(width: Int, height: Int, maxEdge: Int): Int {
        var sample = 1
        while (width / sample > maxEdge * 2 || height / sample > maxEdge * 2) sample *= 2
        return sample
    }

    private fun estimateTokens(text: String): Int = (text.length / 4).coerceAtLeast(1)

    private companion object {
        const val THOUGHT_CHANNEL = "thought"
        const val MAX_IMAGE_EDGE = 1024
    }
}
