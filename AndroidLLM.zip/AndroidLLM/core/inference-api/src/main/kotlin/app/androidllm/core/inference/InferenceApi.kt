package app.androidllm.core.inference

import app.androidllm.core.model.ChatMessage
import app.androidllm.core.model.EngineType
import app.androidllm.core.model.GenerationConfig
import app.androidllm.core.model.ImageAttachment
import app.androidllm.core.model.LocalModel
import app.androidllm.core.model.Modality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

data class EngineCapabilities(
    val engineType: EngineType,
    val modalities: Set<Modality>,
    val supportsStop: Boolean,
    val supportsThinking: Boolean,
    val backends: Set<String>,
)

sealed interface EngineState {
    data object Idle : EngineState
    data class Loading(val modelId: String, val requestedBackend: String = "AUTO") : EngineState
    data class Ready(val modelId: String, val activeBackend: String = "CPU") : EngineState
    data class Failed(val message: String) : EngineState
}

data class LoadOptions(
    val backend: String = "AUTO",
    val contextSize: Int = 4096,
    val cpuThreads: Int? = null,
    val gpuLayers: Int? = null,
)

data class SessionConfig(
    val generation: GenerationConfig,
    val initialMessages: List<ChatMessage> = emptyList(),
)

data class ChatRequest(
    val text: String,
    val history: List<ChatMessage>,
    val images: List<ImageAttachment> = emptyList(),
)

data class InferenceMetrics(
    val timeToFirstTokenMs: Long,
    val generatedTokens: Int,
    val tokensPerSecond: Double,
    val totalTimeMs: Long,
)

sealed interface GenerationEvent {
    data object Started : GenerationEvent
    data class TextDelta(val text: String) : GenerationEvent
    data class ThinkingDelta(val text: String) : GenerationEvent
    data class Metrics(val value: InferenceMetrics) : GenerationEvent
    data object Completed : GenerationEvent
}

interface InferenceEngine : AutoCloseable {
    val capabilities: EngineCapabilities
    val state: StateFlow<EngineState>
    val activeBackend: StateFlow<String?>

    suspend fun load(model: LocalModel, options: LoadOptions = LoadOptions())
    suspend fun createSession(config: SessionConfig): ChatSession
    suspend fun unload()
}

interface ChatSession : AutoCloseable {
    fun generate(request: ChatRequest): Flow<GenerationEvent>
    suspend fun stop()
    suspend fun reset()
}
