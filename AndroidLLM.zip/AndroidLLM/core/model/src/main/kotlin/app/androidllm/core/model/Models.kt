package app.androidllm.core.model

import java.util.UUID

enum class EngineType {
    LITERT,
    GGUF,
}

enum class Modality {
    TEXT,
    IMAGE,
}

enum class PerformanceTier {
    FAST,
    BALANCED,
    SLOW,
}

/**
 * Preset of the device capabilities. Selected by RAM tier (works for most
 * smartphones) and drives conservative defaults: context size, max output
 * tokens and the preferred backend.
 */
enum class DevicePreset(
    val contextSize: Int,
    val maxOutputTokens: Int,
    val backend: String,
) {
    LOW(contextSize = 1024, maxOutputTokens = 256, backend = "CPU"),
    MEDIUM(contextSize = 2048, maxOutputTokens = 512, backend = "CPU"),
    HIGH(contextSize = 3072, maxOutputTokens = 768, backend = "AUTO"),
    FLAGSHIP(contextSize = 4096, maxOutputTokens = 1024, backend = "AUTO"),
    ;

    companion object {
        const val AUTO = "AUTO"

        fun forRamGb(gb: Int): DevicePreset = when {
            gb < 4 -> LOW
            gb < 6 -> MEDIUM
            gb < 8 -> HIGH
            else -> FLAGSHIP
        }
    }
}

/**
 * Per-model overrides applied on top of the device preset and the global
 * generation settings. Null fields mean "use the default".
 */
data class ModelOverrides(
    val contextSize: Int? = null,
    val maxOutputTokens: Int? = null,
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val backend: String? = null,
    val showThinking: Boolean? = null,
)

data class LocalModel(
    val id: String,
    val displayName: String,
    val engineType: EngineType,
    val format: String,
    val sizeBytes: Long,
    val modalities: Set<Modality>,
    val location: String = "",
    val isInstalled: Boolean = false,
    val fileName: String = "",
    val downloadUrl: String = "",
    val modelCardUrl: String = "",
    val sha256: String = "",
    val license: String = "Apache-2.0",
    val recommendedContextSize: Int = 2048,
    val performanceTier: PerformanceTier = PerformanceTier.BALANCED,
    val runtimeAvailable: Boolean = true,
    val isCustom: Boolean = false,
)

enum class ChatRole {
    USER,
    ASSISTANT,
    SYSTEM,
}

data class ImageAttachment(
    val uri: String,
    val mimeType: String = "image/*",
    val displayName: String? = null,
)

/**
 * A document attached to the chat and used as retrieval context (simple RAG):
 * the text is chunked and the most relevant excerpts are injected into the
 * prompt of the next message.
 */
data class AttachedDocument(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val text: String,
    val charCount: Int = text.length,
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: ChatRole,
    val text: String,
    val thinking: String = "",
    val images: List<ImageAttachment> = emptyList(),
    val isStreaming: Boolean = false,
)

data class GenerationConfig(
    val temperature: Float = 0.7f,
    val topP: Float = 0.95f,
    val topK: Int = 40,
    val maxOutputTokens: Int = 512,
    val contextSize: Int = 4096,
    val systemPrompt: String = "You are a helpful local assistant.",
    val showThinking: Boolean = false,
    val renderMarkdown: Boolean = true,
)
