# Каталог AndroidLLM 0.4 для realme C71

Все URL ниже проверены анонимным Range-запросом: HTTP 206 без cookie и Hugging Face token.

## LiteRT-LM

### Qwen2.5 1.5B Instruct Q8

- 1 597 931 520 байт;
- текст, Apache-2.0;
- SHA-256 `faa60663b333290c1496c499828b21d3e3254a788cacd8cce917ce0f761a2dc9`;
- [страница](https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct);
- [файл](https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm?download=true).

### Qwen2-VL 2B Instruct

- 1 784 096 288 байт;
- VLM: текст + изображение, Apache-2.0;
- SHA-256 `a9fd50536f8c521ae7cc1d56a3c58b405b2be83b3899ea8dfca9858eee9a4296`;
- [страница](https://huggingface.co/litert-community/Qwen2-VL-2B);
- [файл](https://huggingface.co/litert-community/Qwen2-VL-2B/resolve/main/Qwen2-VL-2B.litertlm?download=true).

### SmolVLM2 2.2B

- 1 511 353 264 байт;
- VLM: текст + изображение, Apache-2.0;
- SHA-256 `c3adc6bc0ef25f1ac4f9fcf5c1be0b4440aac38929671baa3f84bb31012c0835`;
- [страница](https://huggingface.co/litert-community/SmolVLM2-2.2B);
- [файл](https://huggingface.co/litert-community/SmolVLM2-2.2B/resolve/main/SmolVLM2-2.2B.litertlm?download=true).

## GGUF / llama.cpp

### Qwen2.5 1.5B Instruct Q4_K_M

- 1 117 320 736 байт;
- Apache-2.0;
- SHA-256 `6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e`;
- [страница](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF);
- [файл](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true).

### Qwen2.5 Coder 1.5B Instruct Q4_K_M

- 1 117 320 768 байт;
- Apache-2.0;
- SHA-256 `cc324af070c2ecbfd324a30884d2f951a7ff756aba85cb811a6ec436933bb046`;
- [страница](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF);
- [файл](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf?download=true).

### SmolLM2 1.7B Instruct Q4_K_M

- 1 055 609 536 байт;
- Apache-2.0;
- SHA-256 `decd2598bc2c8ed08c19adc3c8fdd461ee19ed5708679d1c54ef54a5a30d4f33`;
- [страница](https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct-GGUF);
- [файл](https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct-GGUF/resolve/main/smollm2-1.7b-instruct-q4_k_m.gguf?download=true).

### Llama 3.2 1B Instruct Q4_K_M

- 807 694 464 байт;
- Llama 3.2 Community License;
- SHA-256 `6f85a640a97cf2bf5b8e764087b1e83da0fdb51d7c9fab7d0fece9385611df83`;
- [страница](https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF);
- [файл](https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf?download=true).

## Рекомендации для T7250

- Сначала проверять Qwen2.5 0.5B или Qwen3 0.6B.
- Из 1–2B начать с Llama 3.2 1B или Qwen2.5 1.5B GGUF.
- Для русского языка предпочтительнее Qwen2.5 1.5B.
- Для кода — Qwen2.5 Coder 1.5B.
- Qwen2-VL 2B и SmolVLM2 2.2B потребуют больше времени и памяти; использовать одно изображение, новый чат и контекст 2048.
- Dynamic RAM не считается физической памятью; перед запуском 2B закрыть фоновые приложения.
