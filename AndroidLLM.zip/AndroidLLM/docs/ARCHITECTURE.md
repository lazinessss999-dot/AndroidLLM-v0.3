# AndroidLLM architecture

The UI depends only on `core:inference-api`. Runtime-specific classes are adapters.

```text
Compose UI -> AndroidLlmViewModel -> InferenceEngine / ChatSession
                                  -> LiteRT-LM (litertlm-android 0.16.1)
                                  -> llama.cpp (GGUF, arm64 CPU)
```

Only one native model may be loaded at a time. Switching a model stops generation,
closes the session, unloads the runtime, then loads the requested engine.

## Configuration layering

Settings resolve in this order (highest priority first):

1. Per-model overrides (`model_settings.json`) — context, max output,
   temperature, top-p, top-k, backend, thinking.
2. Global generation settings — temperature, top-p, top-k, thinking,
   system prompt, Markdown.
3. Device preset (by RAM tier) — context size, max output tokens, default backend.
4. Engine defaults.

Image references use persisted Android document URIs in the app layer. Native adapters
will either consume a file descriptor or copy to app-private model/input storage.
